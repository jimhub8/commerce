@extends('layouts.app')

@section('content')
<v-app id="inspire">
<my-register></my-register>
</v-app>
@endsection
