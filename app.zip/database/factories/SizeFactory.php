<?php

use Faker\Generator as Faker;

$factory->define(App\models\Size::class, function (Faker $faker) {
    return [
        //
    ];
});
