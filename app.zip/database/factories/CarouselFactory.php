<?php

use Faker\Generator as Faker;

$factory->define(App\Carousel::class, function (Faker $faker) {
    return [
        //
    ];
});
