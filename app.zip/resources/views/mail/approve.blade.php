@component('mail::message')
Approved
Thanks,<br>
{{ config('app.name') }}
@endcomponent
