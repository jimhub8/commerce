@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">Dellmat</div>
                <div class="card-body">
                    <p>Thank you for choosing us. You will get an email when your request us approved</p>
                     <a href="/" class="btn btn-primary">Go to website</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

