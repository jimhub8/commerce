<template>
<v-content>
    <v-container fluid fill-height>
        <v-layout justify-center align-center>
            <h2 class="text-center" style="margin: 200px; color: red; font-size: 36px; padding: 20px; font-weight: 600;">You are not authorized to access this page</h2>
            
        </v-layout>
    </v-container>
</v-content>
</template>

<script>
export default {
}
</script>
 