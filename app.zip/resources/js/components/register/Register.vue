<template>
<v-stepper v-model="e6" vertical>
    <v-stepper-step :complete="e6 > 1" step="1">
        User Details
        <small>Summarize if needed</small>
    </v-stepper-step>

    <v-stepper-content step="1" style="background: #fff;">
        <v-card color="grey lighten-1" class="mb-5">
            <Company></Company>
        </v-card>
        <v-btn color="primary" @click="companyAdd">Continue</v-btn>
        <v-btn flat>Cancel</v-btn>
    </v-stepper-content>

    <v-stepper-step :complete="e6 > 2" step="2">Company details</v-stepper-step>

    <v-stepper-content step="2" style="background: #fff;">
        <v-card color="grey lighten-1" class="mb-5">
            <Register></Register>
        </v-card>
        <v-btn color="primary" @click="userAdd">Finish</v-btn>
        <v-btn flat>Cancel</v-btn>
    </v-stepper-content>
</v-stepper>
</template>

<script>
import Register from './register/Register.vue';
import Company from './register/Company.vue';
export default {
    components: {
        Register, Company
    },
    data() {
        return {
            e6: 1, 
            company_id: null
        }
    },
    methods: {
        companyAdd() {
          eventBus.$emit("CompanyEvent");
        },
        userAdd() {
          eventBus.$emit("userEvent", this.company_id);
        }
    },
    created() {
        eventBus.$on('userResponse', data => {
            window.location.replace('/thankyou')            
        })
        eventBus.$on('companyResponse', data => {
            this.e6 = 2 
            // this.userAdd(data)
            this.company_id = data
        })
    },
}
</script>
