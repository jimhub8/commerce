<?php

use Faker\Generator as Faker;

$factory->define(App\models\Size_product::class, function (Faker $faker) {
    return [
        //
    ];
});
