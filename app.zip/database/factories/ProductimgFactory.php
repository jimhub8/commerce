<?php

use Faker\Generator as Faker;

$factory->define(App\Productimg::class, function (Faker $faker) {
    return [
        //
    ];
});
