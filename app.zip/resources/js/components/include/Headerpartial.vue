<template>
<section class="bg-title-page p-t-50 p-b-40 flex-col-c-m">
    <h2 class="l-text2 t-center" style="color: #000;text-transform: none;">
        Dell<span style="color: rgba(2, 234, 0, 0.58);">Mat</span>
    </h2>
    <p class="m-text13 t-center">
        Living in the future 
    </p>
</section>
</template>

<script>
export default {

}
</script>

<style scoped>
.bg-title-page{ 
    background-image: url(/storage/img/8.jpg) !important;
    background-attachment: fixed !important;
}
</style>
